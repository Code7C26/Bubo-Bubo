﻿#Jump start(va al principio)

##PERSOANJES
#Imagenes

#Gwen
image gleen nb = "gwennb.png"
image gaen h = "gwenh.png"
image gwen m = "gwenm.png"

#Bela
image bela nor = "belanor.png"
image bela emo = "belaemo.png"
image bela cal = "belacal.png"
image bela eno = "belaeno.png"
image bela tri = "belatri.png"
#bocacerradaxd
image bela norc = "belanorc.png"
image bela emoc = "belaemoc.png"
image bela calc = "belacalc.png"
image bela enoc = "belaenoc.png"
image bela tric = "belatric.png"

#Damian
image damian nor = "damiannor.png"
image damian emo = "damianemo.png"
image damian eno = "damianeno.png"
image damian tri = "damiantri.png"
#bc
image damian norc = "damiannorc.png"
image damian emoc = "damianemoc.png"
image damian enoc = "damianenoc.png"
image damian tric = "damiantric.png"

#Lucia
image lucia nor = "lucianor.png"
image lucia emo = "luciaemo.png"
image lucia eno = "luciaeno.png"
image lucia tri = "luciatri.png"
#bc
image lucia norc = "lucianorc.png"
image lucia emoc = "luciaemoc.png"
image lucia enoc = "luciaenoc.png"
image lucia tric = "luciatric.png"


#Benjamin
image benja nor = "benjanor.png"
image benja emo = "benjaemo.png"
image benja cal = "benjacal.png"
image benja eno = "benjaeno.png"
image benja tri = "benjatri.png"
#bc
image benja norc = "benjanorc.png"
image benja emoc = "benjaemoc.png"
image benja calc = "benjacalc.png"
image benja enoc = "benjaenoc.png"
image benja tric = "benjatric.png"

#playero
image playero nor = "playero.png"
image playero norc= "playeroc.png"

#defino persoanjes
define b= Character("Bela")
define d= Character("Damian")
define l= Character("Lucia")
define v= Character("Benjamin")
define p= Character("Playero")
#Prota
default perselect = ""
default vos = ""
define n = DynamicCharacter("vos")

#variables economicos
default ing=2500000
default din=100000
default aho=500000

default renta = 700000
default renta_pagada = False
default luz = 100000
default luz_pagada = False
default gasnatural = 50000
default gasnatural_pagado = False
default agua = 25000
default agua_pagada = False
default internet = 50000
default internet_pagado = False


#aprobo o no
default apro=1

#variables de funciones
default monto_ahorro = ""
default retiro = ""
default ya_ahorro = False

#variable de supermercado
default etapa = 0
default montfin = 0

define frutas = 30000
define verduras = 50000
define fideos = 10000
define carnes = 80000
define snaks = 30000
define galletas = 20000

default frutas_compradas = False
default fideos_comprados = False
default verduras_compradas = False
default carnes_compradas = False
default galletas_compradas = False
default snacks_comprados = False

#variables extra de opciones
default com = False
default uber = False
default decision = False
default auto = False

##FUNCIONES
#funcion de ahorro
init python:
    def ahorrar_dinero(monto):
        if monto > 0 and monto <= 50000:
            store.din -= monto
            store.aho += monto
            store.monto_ahorro = ""
            store.ya_ahorro = True  # <-- Marcamos que ya se realizó la acción
            renpy.hide_screen("ahorrar")
        elif monto > 50000:
            renpy.notify("No puedes ahorrar mas de $50 al dia")
        else:
            renpy.notify("Monto inválido o dinero insuficiente.")

init python:
    def pagar_gasto(nombre, precio, variable_pagada):
        if getattr(store, variable_pagada):
            renpy.notify("¡Ya pagaste " + nombre + "!")

        elif store.din >= precio:
            store.din -= precio
            setattr(store, variable_pagada, True)
            renpy.notify("¡Pagaste " + nombre + "!")

        else:
            renpy.notify("No tenés dinero suficiente.")

init python:
    def retirar_aho(monto):
        if monto <= 0:
            renpy.notify("Ingresá un monto válido.")

        elif monto > store.aho:
            renpy.notify("No tenés suficientes ahorros.")

        else:
            store.aho -= monto
            store.din += monto
            store.retiro = ""
            renpy.hide_screen("retirar")
            renpy.notify("¡Retiraste tus ahorros!")

init python:
    def comprar(producto, precio):
        if getattr(store, producto):
            store.montfin -= precio
            setattr(store,producto,False)
        else:
            store.montfin += precio
            setattr(store,producto,True)

#init python:
    #def pagar(monto):
        #if store.din < monto:
            #renpy.notify("Dinero insuficiente")
        #elif monto<=0:
           # renpy.notify("No puedes irte sin comprar")
       # else:
        #    store.din-=monto
         #   renpy.notify("Compras pagadas")
          #  renpy.return_statement()


#pantallas predefinidas
screen estadisticas():
    frame:
        background "#00000095"
        xalign 0.98
        yalign 0.05

        padding (15, 10)

        vbox:
            spacing 8

            text "ESTADÍSTICAS"
            text "Dinero: $[din]"

screen estacompu():
    on "show" action Play("sound", "audio/windows.mp3")
    modal True
    
    add "fondos/popupwin.png" at Transform(xalign=0.5, yalign=0.5, xoffset=50, yoffset=-5)

    frame:
        background None
        xalign 0.5
        yalign 0.5

        xsize 700
        ysize 700

        padding (15, 10)

        vbox:
            spacing 15

            text "ESTADÍSTICAS" color "#000000" size 40
            text "Ingresos fijos: $[ing]" color "#000000" size 30
            text "Ahorro: $[aho]" color "#000000" size 30

            text "GASTOS FIJOS" color "#000000" size 30
            text "Vivienda: $[renta]" color "#000000" size 30
            text "Gasnatural: $[gasnatural]" color "#000000" size 30
            text "Luz: $[luz]" color "#000000" size 30
            text "Agua: $[agua]" color "#000000" size 30
            text "Internet: $[internet]" color "#000000" size 30

            text "TU DINERO" color "#000000" size 40
            text "Dinero: $[din]" color "#000000" size 30

            null height 20
        hbox:
            xalign 0.5
            yoffset 660
            spacing 15
            textbutton "Consultar ahorros":
                xalign 0.5
                text_size 40
                action Show("consultarahorros")


            textbutton "Pagar gastos":
                xalign 0.5
                text_size 40
                action Show("pagargastos")

            textbutton "Salir":
                text_size 40
                action If(
                    renta_pagada and luz_pagada and gasnatural_pagado and agua_pagada and internet_pagado,
                    Return(),
                    Notify("¡Todavía te quedan gastos por pagar!")
    )   

screen consultarahorros():
    modal True
    add "fondos/popupwin2.jpg" at Transform(xalign=0.5, yalign=0.5, xoffset=20, yoffset=-30)
    frame:
        background None
        xalign 0.5
        yalign 0.5

        xsize 600
        padding (25, 20)

        vbox:
            spacing 15

            text "MIS AHORROS" color "#000000" size 40
            text "Dinero ahorrado: $[aho]" color "#000000" size 30
            text "Dinero disponible: $[din]" color "#000000" size 30

            textbutton "Ahorrar":
                xalign 0.5
                text_size 30
                action Show("ahorrar")

            textbutton "Retirar":
                xalign 0.5
                text_size 30
                action Show("retirar")

            textbutton "Volver":
                xalign 0.5
                text_size 40
                action Hide("consultarahorros")
 
screen retirar():
    modal True
    add "fondos/popupwin2.jpg" at Transform(xalign=0.5, yalign=0.5, xoffset=20, yoffset=-30)
    frame:
        background None
        xalign 0.5
        yalign 0.5

        xsize 600
        padding (25, 20) 
        vbox:
            spacing 15
            text "¿Cuánto dinero desear retirar de tu ahorro?" color "#000000" size 30
            text "Dinero disponible en ahorros: $[aho]" color "#000000" size 30

            input:
                id "retiro"
                value VariableInputValue("retiro")
                length 10
                allow "0123456789"

            textbutton "Confirmar":
                text_size 40
                action Function(retirar_aho, int(retiro or 0))

            textbutton "Volver":
                text_size 40
                action Hide("retirar")

screen ahorrar():
    modal True

    add "fondos/popupwin2.jpg" at Transform(xalign=0.5, yalign=0.5, xoffset=20, yoffset=-30)
    frame:
        background None
        xalign 0.5
        yalign 0.5

        xsize 600
        padding (25, 20)

        vbox:
            spacing 15

            text "¿Cuánto dinero necesitas ahorrar?" color "#000000" size 30
            text "(Maximo de ahorro $50000)" color "#000000" size 30
            text "Dinero disponible: $[din]" color "#000000" size 30

            input:
                id "monto_ahorro"
                value VariableInputValue("monto_ahorro")
                length 10
                allow "0123456789"

            textbutton "Confirmar":
                text_size 40
                sensitive not ya_ahorro
                action Function(ahorrar_dinero, int(monto_ahorro or 0))

            textbutton "Volver":
                text_size 40
                action Hide("ahorrar")

screen pagargastos():
    modal True

    add "fondos/popupwin.png" at Transform(xalign=0.5, yalign=0.5, xoffset=60, yoffset=-30)
    frame:
        background None
        xalign 0.5
        yalign 0.5

        xsize 700
        padding (25, 20)

        vbox:
            spacing 15

            text "PAGAR GASTOS" color "#000000" size 40
            text "Dinero disponible: $[din]" color "#000000" size 30

            hbox:
                spacing 20
                text "Renta: $[renta]" color "#000000" size 30
                textbutton "Pagar":
                    text_size 30
                    action Function(pagar_gasto, "la renta", renta, "renta_pagada")
                    if renta_pagada:
                        sensitive False

            hbox:
                spacing 20
                text "Luz: $[luz]" color "#000000" size 30
                textbutton "Pagar":
                    text_size 30
                    action Function(pagar_gasto, "la luz", luz, "luz_pagada")
                    if luz_pagada:
                        sensitive False

            hbox:
                spacing 20
                text "Gas natural: $[gasnatural]" color "#000000" size 30
                textbutton "Pagar":
                    text_size 30
                    action Function(pagar_gasto, "el gas", gasnatural, "gasnatural_pagado")
                    if gasnatural_pagado:
                        sensitive False

            hbox:
                spacing 20
                text "Agua: $[agua]" color "#000000" size 30
                textbutton "Pagar":
                    text_size 30
                    action Function(pagar_gasto, "el agua", agua, "agua_pagada")
                    if agua_pagada:
                        sensitive False

            hbox:
                spacing 20
                text "Internet: $[internet]" color "#000000" size 30
                textbutton "Pagar":
                    text_size 30
                    action Function(pagar_gasto, "el internet", internet, "internet_pagado")
                    if internet_pagado:
                        sensitive False

            null height 10

            textbutton "Volver":
                text_size 40
                xalign 0.5
                action Hide("pagargastos")

screen elegirpersonaje():
    frame:
        background "#00000095"
        xalign 100
        yalign 50

        padding (25, 15)

        text "¡Elige tu personaje!"

    add "gwen m":
        xalign 0.2
        yalign 0.5
    
    add "gaen h":
        xalign 0.5
        yalign 0.5

    add "gleen nb":
        xalign 0.8
        yalign 0.5

    textbutton "Gwen":
        xalign 0.2
        yalign 0.1
        xoffset 180
        yoffset -50
        action Return("Gwen")

    textbutton "Gaen":
        xalign 0.48
        yalign 0.1
        yoffset -90
        action Return("Gaen")

    textbutton "Gleen":
        xalign 0.67
        yalign 0.1
        yoffset -60
        action Return("Gleen")

screen supermercado():
    frame:
        background "#00000095"
        hbox:
            text "¡Elije que comprar!" size 40
            null width 600
            text "Total: $ [montfin]"
        xalign 0.4
        yalign 0.5

        xsize 1200
        ysize 1000

        padding (15, 10)
        hbox:
            yalign 0.6
            xalign 0.6
            vbox:
                imagebutton:
                    idle "fondos/frutas.png"
                    hover "fondos/fff.png"

                    selected_idle "fondos/ffo.png"
                    selected_hover "fondos/ffof.png"

                    selected frutas_compradas

                    action Function(comprar, "frutas_compradas", frutas)
                text "Frutas: $30000" size 30 
                imagebutton:
                    idle "fondos/fideos.png"
                    hover "fondos/ff.png"

                    selected_idle "fondos/fo.png"
                    selected_hover "fondos/fof.png"

                    selected fideos_comprados

                    action Function(comprar, "fideos_comprados", fideos)
                text "Fideos: $10000" size 30 
            vbox:
                imagebutton:
                    idle "fondos/verduras.png"
                    hover "fondos/vf.png"

                    selected_idle "fondos/vo.png"
                    selected_hover "fondos/vof.png"

                    selected verduras_compradas

                    action Function(comprar, "verduras_compradas", verduras)
                text "Verduras: $50000" size 30 
                imagebutton:
                    idle "fondos/carnes.png"
                    hover "fondos/cf.png"

                    selected_idle "fondos/co.png"
                    selected_hover "fondos/cof.png"

                    selected carnes_compradas

                    action Function(comprar, "carnes_compradas", carnes)
                text "Carnes: $80000" size 30 
            vbox:
                imagebutton:
                    idle "fondos/galletas.png"
                    hover "fondos/gf.png"

                    selected_idle "fondos/go.png"
                    selected_hover "fondos/gof.png"

                    selected galletas_compradas

                    action Function(comprar, "galletas_compradas", galletas)
                text "Galletas: $20000" size 30 
                imagebutton:
                    idle "fondos/snaks.png"
                    hover "fondos/sf.png"

                    selected_idle "fondos/so.png"
                    selected_hover "fondos/sof.png"

                    selected snacks_comprados

                    action Function(comprar, "snacks_comprados", snaks)
                text "Snacks: $30000" size 30
        textbutton "pagar":
            xalign 1.0
            yalign 1.0

            background "#75C9B7"
            hover_background "#55A995"

            action If(
                montfin <= 0,
                Notify("¡No puedes irte sin comprar!"),
            If(
                din < montfin,
                Notify("Dinero insuficiente"),
                Return(montfin)
                )
            )
            
           

screen final():
    frame:
        background "#00000095"
        hbox:
            text "¡Practica completada!" size 40
            null width 600
        xalign 0.4
        yalign 0.5

        xsize 1200
        ysize 1100

        padding (15, 10)
        if perselect=="Gwen":
            add "gwen m"
            xalign 0.2
            yalign 0.5
        elif perselect=="Gaen":
            add "gaen h"
            xalign 0.2
            yalign 0.5
        else:
            add "gleen nb"
            xalign 0.2
            yalign 0.5
        vbox:
            xalign 0.8
            yalign 0.1

            text "CONDICION:"
            if din>0:
                text "Aprobado"
            else:
                text "Desaprobado"
            text "ESTADISTICAS FINALES"
            text "Dinero final: $[din]"
            text "Ahorrado: $[aho]"
            text "Deudas: $0"

        textbutton "Siguiente":
            xalign 1.0
            yalign 1.0

            action Return()
        



#
label start:

    stop music fadeout 3.0
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    scene negro
    with dissolve
    pause 1.0

    scene negro
    with dissolve
    $ perselect = renpy.call_screen("elegirpersonaje")
    $ vos = perselect + " (vos)"
    "Has seleccionado a: [perselect]"
    show screen estadisticas

    

    scene habitacion
    $renpy.notify("Lunes/Semana 1")
    play sound "alarma.mp3" volume 0.5
    n "..." 
    "El pitido de la alarma suena."
    "Sientes como el sonido alcanza tus oídos y te alerta lentamente del comienzo de un nuevo dia."
    stop sound
    "Detienes la alarma."
    n "Que rápido pasa el fin de semana, un parpadeo y nuevamente es lunes..."
    n "Deberían agregar un dia más, y que obviamente cuente como no laborable."
    n "..."
    n "Realmente quiero dormir, aunque sea 15 minutos más..."
    n "..."
    n "..."
    n "Bien, necesito alistarme para salir. Tengo mucho trabajo acumulado por hacer."

    scene negro
    stop music fadeout 3.0
    play sound "ascensor.mp3" volume 0.5
    $ renpy.pause(4.0, hard=True)
    with dissolve

    scene oficina
    play music "audio/oficina.mp3" fadein 3.0 volume 0.3
    with dissolve

    play sound "vibrar.mp3" volume 5
    $ renpy.pause(1.0, hard=True)

    "Sientes como el reloj inteligente de tu muñeca vibra."
    "Ves como indica la hora, dia y el clima."
    " ' 7:30 am, lunes 23 de Julio, nublado.'"
    "Sientes como el sonido del entorno y las charlas, junto al olor a café recién preparado, te envuelve."
    "La silueta de alguien acercandose llama tu atención y te desconecta del estado en el que te encontrabas."
    show benja nor
    v "¡Buenas [perselect]! tanto tiempo sin verte, ja."
    show benja norc
    n "Buenos dias."
    n "Creo que verte la cara todos los días va a comenzar a pasarme factura. " 
    n "Ni siquiera voy a mencionar la juntada del viernes pasado."
    show benja cal
    v "Hey, que no sepas identificar las señales en el truco no es culpa de mi cara."
    show benja calc
    n "Sos muy malo dando señales..."
    n "Haces tantos gestos que me cuesta seguirte el ritmo."
    show benja tri
    v "Creo que a la próxima voy a elegir otro compañero, con vos perdimos 3 veces seguidas..."
    show benja tric
    show lucia eno at left
    l "¡Chicos!"
    l "Dejen la charla para despúes, tenemos muchas cosas que hacer."
    show lucia enoc at left
    show benja calc
    n "Buenos días para vos también, Luci."
    n "¿No nos vas a saludar?"
    show lucia emo at left
    l "Sí, disculpa. Buenos dias, a los dos."
    show lucia emoc at left
    show damian nor at right
    d "Buenas, ¿cómo dicen que les va?"
    d "¿Pelean desde tan temprano?"
    show damian norc
    n "Hablabamos sobre nuestra mala racha en la juntada."
    show benja emo
    show lucia enoc
    v "Y que a Luci le encanta retarnos todo el tiempo."
    show damian tric
    show benja emoc
    show lucia eno
    l "¿Qué? disculpame por intentar tener compañeros de trabajo responsables."
    show damian norc
    show lucia nor
    l "En fin, venia a repartirles estos papeles."
    play sound "papeles.mp3" volume 3
    $ renpy.pause(1.0, hard=True)
    show lucia eno
    l "Y a recordarles que tienen que ponerse las pilas, debemos entregar este proyecto a tiempo el viernes."
    show lucia enoc
    n "Dios... es un montón."
    n "..."
    n "Bueno, entonces yo me encargo de esta parte..."

    scene negro
    stop music fadeout 3.0
    play sound "puerta.mp3" volume 0.5
    $ renpy.pause(1.0, hard=True)
    with dissolve

    scene habitacion
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    with dissolve

    $din+=ing
    $renpy.notify("ganado $1200000")
    n "Finalmente en casita..."
    play sound "vibrar.mp3" volume 5
    $ renpy.pause(1.0, hard=True)
    "El reloj vibra, ves un recordatorio en la pantalla."
    "' Pagar los gastos mensuales, NO OLVIDAR.'"
    n "Cierto, debo de pagar mis cuentas lo antes posible."
    n "Justo hoy me depositaron, entonces lo haré ahora y despúes cenaré."
    n "..."
    n "Ah, de paso podría consultar mis ahorros."
    
    scene compu
    call screen estacompu
    scene habitacion
    n "Genial, todo listo."
    n "..."
    n "Hoy fue un dia realmente largo y agotador."
    n "¿Debería pedir comida a domicilio?"
    while not com:
        menu:
            n "¿Debería pedir comida a domicilio?"

            "Si (precio $25000)":
                if din>=25000:
                    $com=True
                    $din-=25000
                    "Deslizas tu dedo por la pantalla, viendo todas las opciones que tienes para pedir."
                    n "Comer una hamburguesa con papás caseras no suena mal."
                    "Ordenas tu comida y pagas lo solicitado."
                    n "Bien, ahora esperemos."
                else:
                    n "Mejor en otro momento, ahora mismo no tengo plata."
            "No":
                n "Solo queda cocinarnos algo."
                $com=True
    
    scene negro
    stop music fadeout 3.0
    with dissolve
    pause 1.0

    scene habitacion
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    with dissolve
    $renpy.notify("Miércoles/Semana 1")

    n "Necesito hacer las compras del super."
    n "El dia de ayer se me paso volando, tengo que ir hoy si o si."
    "Escribes la lista del super en un mensaje de texto."
    n "Ah, además tengo que pasar por la estación de gas a cargar el tanque."
    n "Tendré que hacerme un tiempito luego del trabajo."

    scene negro
    stop music fadeout 3.0
    play sound "ascensor.mp3" volume 0.5
    $ renpy.pause(4.0, hard=True)
    with dissolve

    scene oficina
    play music "audio/oficina.mp3" fadein 3.0 volume 0.3
    with dissolve
    show lucia enoc

    "Ves como las puertas del ascensor se abren."
    "La luz de la oficina te deslumbra, y, por unos segundos, a tus ojos les cuesta acostumbrarse."
    l "Ugh..."
    n "Hola Luci."
    n "¿Estás bien?"
    show lucia eno
    l "Buenos dias, [perselect]."
    show lucia enoc
    n "Te ves... algo irritada."
    show lucia eno
    l "Damián olvidó poner la alarma."
    l "A pesar de que se lo recordé varias veces."
    l "Nos quedamos dormidos, y olvidé un informe importante en casa."
    show lucia tri
    "Observas la preocupación en sus ojos, entonces tu también te preocupas."
    "..."
    n "Si quieres puedo ayudarte a rehacerlo, ya me liberé un poco de mis tareas."
    show lucia emo
    l "¿En serio? eso me sería de mucha ayuda."
    l "..."
    l "¿No te es problema ayudarme?"
    n "No te preocupes, vos siempre me ayudas cuando lo necesito."
    n "Además, somos amigos, para eso estamos."
    show lucia nor
    l "¡Muchisimas gracias!"
    l "Entonces empecemos ahora, es mucho lo que debemos hacer."

    scene negro
    stop music fadeout 3.0
    with dissolve
    pause 1.0

    scene oficina
    play music "audio/oficina.mp3" fadein 3.0 volume 0.3
    with dissolve
    show lucia nor at left
    l "Gracias por ayudarme, no creo que hubiese podido entregarlo a tiempo si no fuera por vos."
    show lucia eno
    l "Espero que Damián no vuelva a olvidar poner la alarma."
    show lucia enoc
    show damian nor
    d "Listo, es hora de salir."
    show damian emo
    d "¿Vamos a casa, Luci?"
    show damian emoc
    l "..."
    show damian tric
    l "..."
    show damian tri
    d "Ah, como estabamos llegando tarde, olvide decirlo hoy en la mañana."
    show lucia emoc
    d "Lo siento, Luci, no voy a volver a olvidarme de la alarma."
    show damian tric
    l "..."
    show damian tri
    d "También siento no haberte escuchado cuando me lo recordaste muchas veces."
    show lucia emo
    show damian norc
    l "Esta bien."
    l "Volvamos a casa."
    show lucia emoc
    n "Parece que los noviecitos volvieron a la normalidad."
    show benja emo at right
    v "¡PORFIN A CASAAAA!"
    v "¡¿QUE ONDA ESTE FINDE?!"
    show benja emoc
    show lucia eno
    l "¡AH!"
    show lucia emo
    l "Ay benja, perdona, me pegaste un susto."
    l "Este finde..."
    l "Creo que si estoy libre."
    show lucia emoc
    show damian emo
    d "Yo tambien puedo."
    show damian nor
    d "¿Vos podes, [perselect]?"
    show damian norc
    menu:
        d "¿Quieres salir?"
        "Si":
            n "Claro, no tengo nada planeado."
            show benja emo
            v "Genial, entonces más tarde les mando un mensaje para que organicemos."
        "No":
            n "La proxima vez, tengo cosas que organizar."
            show benja cal
            v "Dale, si cambias de opinion escribinos."
    "Escuchas una voz a lo lejos, parece estar llamando a alguien."
    show benja cal
    v "Ah, me llaman por allá, despúes nos vemos."
    show benja nor
    v "Adiós."
    hide benja 
    show damian nor
    d "Cualquier cosa nos escribís, nosotros vamos yendo a casa."
    n "Si, nos vemos mañana."
    hide damian
    hide lucia
    n "..."
    n "Es momento de hacer las compras, antes de que se haga demasiado tarde."

    scene negro 
    stop music fadeout 3.0
    play sound "auto.mp3" volume 1
    $ renpy.pause(2.0, hard=True)
    with dissolve

    scene supermercado
    play music "audio/super.mp3" fadein 3.0 volume 0.3
    play sound "supermercado.mp3" volume 0.5 loop
    with dissolve
    "Ves el nombre del supermercado al levantar la vista."
    " 'Autosuper El Nido' "
    "Sientes el cambio de temperatura al entrar en el local, buscas la lista de compras del mes en tu celular."
    n "Bien..."
    n "Vamos a comprar."
    call screen supermercado
    "Dejas la mercadería en la cinta del cajero."
    "Comienzas a cobrar cada producto con el scanner."
    play sound "scanner.mp3" volume 3
    $ renpy.pause(4.0, hard=True)
    stop sound
    "..."
    "Ves en la pantalla el precio total de la compra."
    "Escaneas el QR generado y pagas."
    $ din -= montfin
    $ montfin = 0
    n "Llevemos estas bolsas al auto, y después a cargar gas."

    scene negro 
    stop music fadeout 3.0
    play sound "auto.mp3" volume 1
    $ renpy.pause(2.0, hard=True)
    with dissolve

    scene estacion
    play music "audio/estacion.mp3" fadein 3.0 volume 0.3
    with dissolve
    show playero nor at right
    p "Buenas, cómo le va?"
    p "¿Quiere que llene el tanque?"
    show playero norc
    while not auto:
        menu:
            "¿Qué quieres?"

            "Llenar el tanque (precio $10000)" :
                if din>=10000:
                    $auto = True
                    show playero nor at right
                    p "Dale."
                    show playero norc
                    "Ves como los números de litros de la máquina suben lentamente."
                    "1 litro... 2 litros... 3 litros..."
                    "..."
                    "..."
                    show playero nor
                    p "Listo, su tanque ya está lleno."
                    p "Este... serian $10000."
                    show playero norc
                    $din-=10000
                    show playero norc at right
                    "Ves como el playero genera el QR."
                    "Acercas tu celular y pagas."
                    show playero nor
                    p "Gracias, que le vaya bien."
                    show playero norc at right
                    jump lleno
                else:
                    n "Ah, me olvidé de que no tengo dinero suficiente para pagar."

            "Dinero insuficiente":
                if din==0 or din<10000:
                    show playero nc at right
                    $auto = True
                    n "Mil disculpas, no tengo suficiente dinero para pagar."
                    show playero n at right
                    p "No se preocupe, que tenga buen dia."
                    jump nolleno
                else:
                    n "Mil disculpas, no tengo suficiente dinero para pagar."
                    n "Ah, espere un momento."
                    "Revisas rápidamente tu cuenta virtual."
                    "..."
                    "Tienes dinero para pagar."
                    n "Debo llenar el tanque."

label lleno:
    scene negro 
    stop music fadeout 3.0
    play sound "puerta.mp3" volume 0.5
    $ renpy.pause(1.0, hard=True)
    with dissolve

    scene habitacion
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    
    with dissolve
    n "Por fin en casa, hoy fue otro dia muy largo..."
    n "Cenaré algo rápido e iré derechito a dormir."

    scene negro 
    stop music fadeout 3.0
    with dissolve
    pause 1.0

    scene habitacion
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    with dissolve
    $renpy.notify ("Sábado/Semana 1")
    n "¡Fin de semana!"
    n "Estaría bueno salir a algún lado, me lo merezco luego de una semana tan larga."
    n "Esta la posibilidad de salir por ahí con mis amigos, como habian sugerido hace un par de días..."
    n "Aunque también podría salir por mi cuenta..."
    n "..."
    play sound "notificacion.mp3" volume 2
    $ renpy.pause(1.0, hard=True)
    "Tus ojos siguen la dirección del sonido."
    "Es tu celular, un nuevo mensaje aparece en la pantalla."
    n "..."
    n "Bela me esta escribiendo."
    n "Veamos..."
    "¡Buenas [perselect]!"
    "Andamos necesitando algo de ayuda por el kiosco, llegaron varios encargos para la tarde..."
    "y un par de manos extra nos servirían mucho, escribeme cualquier cosa."
    n "Mmmmm... algo de dinero extra no estaría mal..."
    n "¿Qué debería hacer?"

    while not decision:
        menu:
            "¿Qué debería hacer?"

            "Salir con tus amigos (gasto $8000)":
                if din >= 8000:
                    $decision = True
                    $din-=8000
                    n "Rechazaré el trabajo, hace tiempo no salgo con mis amigos."
                    "Comienzas a escribir en tu celular."
                    "'Hoy no puedo, ya tenía un compromiso programado.'"
                    "'Gracias por avisar, Bela.'"
                    "'Mensaje enviado'."
                    "Bloqueas tu celular y comienzas a alistarte para salir."
                    

                    scene negro 
                    stop music fadeout 3.0
                    play sound "pasos.mp3" volume 2
                    $ renpy.pause(1.0, hard=True)
                    with dissolve

                    scene cafesalida
                    play music "audio/cafe.mp3" fadein 3.0 volume 0.3
                    with dissolve
                    scene cafed
                    d "¡[perselect], por acá!"
                    scene cafev
                    v "Y... estamos completos."
                    scene cafesalida
                    n "Hola chicos, perdonen la demora, me habia surgido algo."
                    n "Ya extrañaba verlos fuera del trabajo..."
                    n "Y ver a Luci de buen humor-"
                    scene cafel
                    l "Mejor sientate y pide algo de una vez..."
                    scene cafesalida
                    n "Jajaja, lo siento Lu, sabes que bromeo."
                    pause 2.0
                    jump continua

                else:
                    n "La próxima vez, ahora no tengo dinero suficiente para salir..."
            
            "Salir por tu cuenta":
                $decision = True
                n "Necesito un descanso, por ahora rechazaré las otras cosas."
                "Comienzas a escribir en tu celular."
                "'Hoy no puedo, tengo algo que hacer.'"
                "'Gracias por avisar, Bela.'"
                "'Mensaje enviado'."
                "Bloqueas tu celular y comienzas a alistarte para salir."
                

                scene negro 
                stop music fadeout 3.0
                play sound "pasos.mp3" volume 2
                $ renpy.pause(1.0, hard=True)
                with dissolve

                scene plaza
                play music "audio/menu.mp3" fadein 3.0 volume 0.3
                with dissolve
                "Decides salir a pasear por la plaza."
                "A lo lejos ves un asiento..."
                "Caminas tranquilamente hacia el y te sientas a descansar."
                "Cierras los ojos y te quedas en silencio, con la espalda apoyada en el respaldar y las piernas estiradas."
                "..."
                "Sientes como el sol penetra lentamente tu piel y el calor te hace senir en calma."
                "El sonido de la leve brisa, junto al olor de flores de jazmín, inunda tus sentidos."
                "..."
                "Suspiras"
                "Dejas salir el aire que contenías junto al peso de lo que ha pasado en la semana."
                "Te das cuenta que ha sido una buena decisión."
                pause 2.0
                jump continua
                
            "Trabajar extra (ganancia $20000)":
                $decision = True
                "Comienzas a escribir en tu celular."
                "'Me alisto y voy para allá.'"
                "'Gracias por avisar, Bela.'"
                "'Mensaje enviado'."
                "Bloqueas tu celular y comienzas a alistarte para salir."

                scene negro 
                stop music fadeout 3.0
                play sound "pasos.mp3" volume 2
                $ renpy.pause(1.0, hard=True)
                with dissolve

                scene kiosko
                play music "audio/kiosko.mp3" fadein 3.0 volume 0.3
                with dissolve
                show bela emo at right
                b "¡Hola [perselect]!"
                n "Hola Bela, tanto tiempo sin verte."
                show bela tri
                b "Me alegro que vinieras, realmente necesitaba de tu ayuda hoy, jaja."
                show bela cal
                b "No sé si te enteraste, pero hoy hay un partido de futbol importante."
                show bela emo
                b "Y todos vienen a comprar acá."
                show bela emoc
                "Tus ojos se mueven inconscientemente a la gran pila de productos que se encuentra detrás de Bela."
                n "Wow, realmente hay mucho trabajo por hacer..."
                n "Me alegro de haber venido a ayudar."
                show bela cal
                b "Si... me gustaría charlar más, pero los clientes no esperan."
                b "¡A trabajar!"
                hide bela

                scene negro 
                stop music fadeout 3.0
                with dissolve
                pause 1.0

                scene kiosko
                play music "audio/kiosko.mp3" fadein 3.0 volume 0.3
                with dissolve
                show bela cal at right
                b "Estoy cansada, hicimos un montón de cosas..." 
                b "Debemos cerrar, antes de que a alguien más se le ocurra venir a comprar algo en el último momento."
                b "Pero antes de que me olvide..."
                "Ves como Bela rebusca en su bolsillo derecho."
                "Bela toma tu muñeca."
                "Abres la mano y sientes un ligero peso en ella."
                b "Gracias por tu ayuda hoy, esa es tu paga."
                $din+=20000
                $renpy.notify ("Ganado $20000")
                show bela nor
                b "Si necesito otra vez de tu ayuda voy a escribirte."
                b "Nos vemos."
                hide bela
                pause 2.0
                jump continua

label nolleno:
    scene negro 
    stop music fadeout 3.0
    play sound "puerta.mp3" volume 0.5
    $ renpy.pause(1.0, hard=True)
    with dissolve

    scene habitacion 
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    with dissolve
    n "Al final no pude cargar el tanque, no se que voy a hacer..."
    n "Con el auto sin gas voy a tener problemas para movilizarme."
    n "..."
    n "Bueno, ya veré como me las arreglo."

    scene negro 
    stop music fadeout 3.0
    with dissolve
    pause 1.0

    scene habitacion
    play music "audio/pieza.mp3" fadein 3.0 volume 0.3
    with dissolve
    $renpy.notify ("Sábado/Semana 1")
    n "¡Fin de semana!"
    n "Estaría bueno salir a algún lado, me lo merezco luego de una semana tan larga."
    n "Está la posibilidad de salir por ahí con mis amigos..."
    n "Aunque también podría salir por mi cuenta..."
    n "..."

    play sound "notificacion.mp3" volume 2
    $ renpy.pause(1.0, hard=True)
    
    "Tus ojos siguen la dirección del sonido."
    "Es tu celular, un nuevo mensaje aparece en la pantalla."
    n "..."
    n "Bela me esta escribiendo."
    n "Veamos..."
    "¡Buenas [perselect]!"
    "Andamos necesitando algo de ayuda por el kiosco, llegaron varios encargos para la tarde..."
    "y un par de manos extra nos servirían mucho, escribeme cualquier cosa."
    n "Mmmmm... algo de dinero extra no estaría mal..."
    n "¿Qué debería hacer?"

    while not decision:
        menu:
            "¿Qué debería hacer?"

            "Salir a merendar con los chicos (gasto $8000)":
                if din >= 5:
                    $din-=5
                    $decision = True
                    n "Rechazaré el trabajo, hace tiempo no salgo con mis amigos."
                    "Comienzas a escribir en tu celular."
                    "'Hoy no puedo, ya tenía un compromiso programado.'"
                    "'Gracias por avisar, Bela.'"
                    "'Mensaje enviado'."
                    "Bloqueas tu celular y comienzas a alistarte para salir."
                    n "Ah..."
                    n "Me olvide de que no cargué gas."
                    n "..."
                    n "Creo que me alcanza para un uber."
                    while not uber:
                        menu:
                            n "¿Pedirse un uber?"

                            "Si (costo $2000)":
                                if din>=2000:
                                    $din-=2000
                                    $ uber = True
                                    "Ingresas tu dirección y pagas."
                                    "..."
                                    "..."
                                    "'Tu uber está en camino.'"
                                    n "Bien, toca esperar."

                                    scene negro 
                                    stop music fadeout 3.0
                                    with dissolve
                                    pause 1.0

                                    scene cafesalida
                                    play music "audio/cafe.mp3" fadein 3.0 volume 0.3
                                    with dissolve
                                    scene cafed
                                    d "¡[perselect], por acá!"
                                    scene cafev
                                    v "Y... estamos completos."
                                    scene cafesalida
                                    n "Hola chicos, perdonen la demora, me habia surgido algo."
                                    n "Ya extrañaba verlos fuera del trabajo..."
                                    n "Y ver a Luci de buen humor-"
                                    scene cafel
                                    l "Mejor sientate y pide algo de una vez..."
                                    scene cafesalida
                                    n "Jajaja, lo siento Lu, sabes que bromeo."
                                    pause 2.0
                                    jump continua
                                else:
                                    n "No tengo dinero suficiente para pedirlo."
                            "no":
                                if din>=2:
                                    "Tienes dinero para pagar el uber."
                                else:
                                    n "No tengo dinero suficiente para pagar."
                                    $ uber = True
                    

                else:
                    n "No tengo dinero suficiente para salir."
            
            "Salir por tu cuenta":
                $decision = True
                n "Necesito un descanso, por ahora rechazaré las otras cosas."
                "Comienzas a escribir en tu celular."
                "'Hoy no puedo, tengo algo que hacer.'"
                "'Gracias por avisar, Bela.'"
                "'Mensaje enviado'."
                "Bloqueas tu celular y comienzas a alistarte para salir."

                scene negro 
                stop music fadeout 3.0
                play sound "pasos.mp3" volume 2
                $ renpy.pause(1.0, hard=True)
                with dissolve

                scene plaza
                play music "audio/menu.mp3" fadein 3.0 volume 0.3
                with dissolve
                "Decides salir a pasear por la plaza."
                "A lo lejos ves un asiento..."
                "Caminas tranquilamente hacia el y te sientas a descansar."
                "Cierras los ojos y te quedas en silencio, con la espalda apoyada en el respaldar y las piernas estiradas."
                "..."
                "Sientes como el sol penetra lentamente tu piel y el calor te hace senir en calma."
                "El sonido de la leve brisa, junto al olor de flores de jazmín, inunda tus sentidos."
                "..."
                "Suspiras"
                "Dejas salir el aire que contenías junto al peso de lo que ha pasado en la semana."
                "Te das cuenta que ha sido una buena decisión."
                pause 2.0
                jump continua
                
            "Trabajar extra (ganancia $20000)":
                $decision = True
                "Comienzas a escribir en tu celular."
                "'Me alisto y voy para allá.'"
                "'Gracias por avisar, Bela.'"
                "'Mensaje enviado'."
                "Bloqueas tu celular y comienzas a alistarte para salir."

                scene negro 
                stop music fadeout 3.0 
                play sound "pasos.mp3" volume 2
                $ renpy.pause(1.0, hard=True)
                with dissolve

                scene kiosko
                play music "audio/kiosko.mp3" fadein 3.0 volume 0.3
                with dissolve
                show bela emo at right
                b "¡Hola [perselect]!"
                n "Hola Bela, tanto tiempo sin verte."
                show bela tri
                b "Me alegro que vinieras, realmente necesitaba de tu ayuda hoy, jaja."
                show bela cal
                b "No sé si te enteraste, pero hoy hay un partido de futbol importante."
                show bela emo
                b "Y todos vienen a comprar acá."
                show bela emoc
                "Tus ojos se mueven inconscientemente a la gran pila de productos que se encuentra detrás de Bela."
                n "Wow, realmente hay mucho trabajo por hacer..."
                n "Me alegro de haber venido a ayudar."
                show bela cal
                b "Si... me gustaría charlar más, pero los clientes no esperan."
                b "¡A trabajar!"
                hide bela

                scene negro
                stop music fadeout 3.0 
                with dissolve
                pause 1.0

                scene kiosko
                play music "audio/kiosko.mp3" fadein 3.0 volume 0.3
                with dissolve
                show bela cal at right
                b "Estoy cansada, hicimos un montón de cosas..." 
                b "Debemos cerrar, antes de que a alguien más se le ocurra venir a comprar algo en el último momento."
                b "Pero antes de que me olvide..."
                "Ves como Bela rebusca en su bolsillo derecho."
                "Bela toma tu muñeca."
                "Abres la mano y sientes un ligero peso en ella."
                b "Gracias por tu ayuda hoy, esa es tu paga."
                $din+=20000
                $renpy.notify ("Ganado $20000")
                show bela nor
                b "Si necesito otra vez de tu ayuda voy a escribirte."
                b "Nos vemos."
                hide bela
                pause 2.0
                jump continua

label continua:
    scene negro
    stop music fadeout 3.0
    play sound "puerta.mp3" volume 0.5
    $ renpy.pause(1.0, hard=True)
    with dissolve

    scene habitacion
    play music "audio/plaza.mp3" fadein 3.0 volume 0.3
    with dissolve
    n "Hoy fue un buen día."
    n "Debo ponerme al dia con algunas cosas y organizarme para la siguiente semana."

    scene negro
    stop music fadeout 3.0
    with dissolve
    pause 1.0

    call screen final
    play music "audio/menu.mp3" fadein 3.0 volume 0.3
    with dissolve
    return ()
    

label acerca_de_bubo:
    # Fondo y personaje
    scene negro
    stop music fadeout 3.0
    with dissolve
    pause 1.0

    scene kiosko
    play music "audio/kiosko.mp3" fadein 3.0 volume 0.3
    with dissolve
    show bela emo at center
    b "¡Hola! Bienvenido a tu evaluación práctica."
    show bela nor
    b "En este apartado te hablaré un poco acerca de Bubo²."
    show bela cal
    b "Bubo² guía a jóvenes y adultos en el dominio de sus finanzas personales, partiendo desde los conceptos económicos más básicos hasta los más avanzados."
    b "Ingresá a bubo2-bubo.web.app para más información."
    show bela emo
    b "¡Disfrutá esta instancia educativa!"

    scene negro
    stop music fadeout 3.0
    with dissolve
    pause 1.0
    # Vuelve automáticamente al menú principal al terminar
    return